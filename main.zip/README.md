# Paint-Play-T18
Fundamentals of Computer Programming using C++ (UST-ZC Fall 2022 - Course Project)
  - OOP oriented project.

# Contributers
  - Hesham Elsaman <<s-hesham.elsaman@zewailcity.edu.eg>>
  - Abdelrahman Fouad Eldreeny <<s-abdelrahman.eldreeny@zewailcity.edu.eg>>
  - Bahy Walid Awad Elsisi <<s-bahy.elsisi@zewailcity.edu.eg>>
  - Makary Magdy Fayez AbdelMalak <<s-makary.fayez@zewailcity.edu.eg>>
